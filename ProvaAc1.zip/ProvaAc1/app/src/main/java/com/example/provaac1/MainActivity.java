package com.example.provaac1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private HabitAdapter habitAdapter;
    private List<Habit> habitList;
    private Button btnAddHabit;

    private int currentEditPosition = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerViewHabits);
        btnAddHabit = findViewById(R.id.btnAddHabit);
        habitList = new ArrayList<>();


        habitAdapter = new HabitAdapter(this, habitList, new HabitAdapter.OnHabitClickListener() {
            public void onEdit(Habit habit) {

                currentEditPosition = habitList.indexOf(habit);


                Intent intent = new Intent(MainActivity.this, HabitFormActivity.class);
                intent.putExtra("name", habit.getName());
                intent.putExtra("description", habit.getDescription());
                startActivityForResult(intent, 2); // Código 2 para edição
            }

            public void onDelete(Habit habit) {
                habitList.remove(habit);
                habitAdapter.notifyDataSetChanged();
            }

            public void onMarkDone(Habit habit) {
                habit.setDoneToday(true);
                habitAdapter.notifyDataSetChanged();
            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(habitAdapter);


        btnAddHabit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, HabitFormActivity.class);
                startActivityForResult(intent, 1); // Código 1 para novo hábito
            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            String name = data.getStringExtra("name");
            String description = data.getStringExtra("description");

            if (requestCode == 1) {

                Habit novo = new Habit(name, description);
                habitList.add(novo);
                habitAdapter.notifyDataSetChanged();
            } else if (requestCode == 2) {

                if (currentEditPosition >= 0 && currentEditPosition < habitList.size()) {
                    Habit habit = habitList.get(currentEditPosition);
                    habit.setName(name);
                    habit.setDescription(description);
                    habitAdapter.notifyDataSetChanged();
                }
            }
        }
    }
}
