package com.example.provaac1;

public class Habit {

        private String name;
        private String description;
        private boolean doneToday;

        public Habit(String name, String description) {
            this.name = name;
            this.description = description;
            this.doneToday = false;
        }

        public String getName() { return name; }
        public void setName(String name) { this.name = name; }

        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }

        public boolean isDoneToday() { return doneToday; }
        public void setDoneToday(boolean doneToday) { this.doneToday = doneToday; }
    }




