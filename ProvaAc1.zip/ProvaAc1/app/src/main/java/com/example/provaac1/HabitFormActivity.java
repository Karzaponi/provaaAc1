package com.example.provaac1;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class HabitFormActivity extends AppCompatActivity {

    private EditText etHabitName, etHabitDescription;
    private Button btnSaveHabit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_habit_form);

        etHabitName = findViewById(R.id.etHabitName);
        etHabitDescription = findViewById(R.id.etHabitDescription);
        btnSaveHabit = findViewById(R.id.btnSaveHabit);


        Intent intent = getIntent();
        if (intent.hasExtra("name")) {
            String name = intent.getStringExtra("name");
            String description = intent.getStringExtra("description");

            etHabitName.setText(name);
            etHabitDescription.setText(description);
        }

        btnSaveHabit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = etHabitName.getText().toString();
                String description = etHabitDescription.getText().toString();

                Intent resultIntent = new Intent();
                resultIntent.putExtra("name", name);
                resultIntent.putExtra("description", description);
                setResult(RESULT_OK, resultIntent);
                finish();
            }
        });
    }
}
