package com.example.provaac1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class HabitAdapter extends RecyclerView.Adapter<HabitAdapter.HabitViewHolder> {

    public interface OnHabitClickListener {
        void onEdit(Habit habit);
        void onDelete(Habit habit);
        void onMarkDone(Habit habit);
    }

    private Context context;
    private List<Habit> habitList;
    private OnHabitClickListener listener;

    public HabitAdapter(Context context, List<Habit> habitList, OnHabitClickListener listener) {
        this.context = context;
        this.habitList = habitList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public HabitViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_habit, parent, false);
        return new HabitViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HabitViewHolder holder, int position) {
        Habit habit = habitList.get(position);
        holder.tvName.setText(habit.getName());
        holder.tvDescription.setText(habit.getDescription());
        holder.checkHabitDone.setChecked(habit.isDoneToday());

        // Clique curto = editar
        holder.itemView.setOnClickListener(v -> listener.onEdit(habit));

        // Clique longo = excluir
        holder.itemView.setOnLongClickListener(v -> {
            listener.onDelete(habit);
            return true;
        });

        // Checkbox = marcar como feito
        holder.checkHabitDone.setOnCheckedChangeListener((buttonView, isChecked) -> {
            habit.setDoneToday(isChecked);
            listener.onMarkDone(habit);
        });
    }

    @Override
    public int getItemCount() {
        return habitList.size();
    }

    static class HabitViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvDescription;
        CheckBox checkHabitDone;

        public HabitViewHolder(View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.textHabitName);
            tvDescription = itemView.findViewById(R.id.textHabitDescription);
            checkHabitDone = itemView.findViewById(R.id.checkHabitDone);
        }
    }
}

